"""Constants for Samsung Jet Bot integration."""
DOMAIN = "samsung_jetbot"
SMARTTHINGS_BASE_URL = "https://api.smartthings.com/v1/devices"
